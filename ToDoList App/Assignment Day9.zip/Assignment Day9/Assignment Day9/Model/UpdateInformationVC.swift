//
//  UpdateInformationVC.swift
//  Assignment Day9
//
//  Created by amritansh kaushik on 10/02/23.
//

import Foundation
import UIKit
import CoreData

class UpdateInformationVC {
 
    var taskTitle = ""
    var taskDescription = ""
    var taskId : UUID?
    var status = false
    
    // MARK: update data if the data was already stored but you wanted to update it
    func updateData(title: String, description: String) {
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let managedContext = appDelegate?.persistentContainer.viewContext
        let fetchRequest : NSFetchRequest<NSFetchRequestResult> = NSFetchRequest.init(entityName: "ToDoList")
        
        let idString = taskId?.uuidString
        fetchRequest.predicate = NSPredicate(format: "id = %@", idString!)
        
        do {
            let results = try managedContext?.fetch(fetchRequest)
            
            let objectUpdate = results![0] as! NSManagedObject
            
            objectUpdate.setValue(title, forKey: "listTitle")
            objectUpdate.setValue(description, forKey: "listDescription")
            
            do {
                try managedContext?.save()
            } catch {
                print(error)
            }
        } catch {
            print(error)
        }
    }
    
    // MARK: create data from scratch
    func createData(title: String, description: String) {
        if title != "" || description != "" {
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            
            let managedContext = appDelegate.persistentContainer.viewContext
            
            let userEntity = NSEntityDescription.insertNewObject(forEntityName: "ToDoList", into: managedContext)
            
            //        let user = NSManagedObject(entity: userEntity!, insertInto: managedContext)
            
            userEntity.setValue(title, forKey: "listTitle")
            userEntity.setValue(description, forKey: "listDescription")
            userEntity.setValue(UUID(), forKey: "id")
            userEntity.setValue(status, forKey: "listStatus")
            
            do {
                try managedContext.save()
            } catch let error as NSError {
                print("cant save the data with error \(error), \(error.userInfo)")
            }
        }
    }
}
