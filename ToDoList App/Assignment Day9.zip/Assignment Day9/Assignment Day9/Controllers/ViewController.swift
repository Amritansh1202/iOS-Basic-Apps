//
//  ViewController.swift
//  Asignment Day 9
//
//  Created by amritansh kaushik on 07/02/23.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    
    var tasksArray = [String]()
    var idArray = [UUID]()
    var descriptionArray = [String]()
    var statusButtonArray = [Bool]()
    var dbArray = [NSManagedObject]()
    
    var currentTaskTitle = ""
    var currentID : UUID?
    var currentDescription = ""
    var currentStatus : Bool = false
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        
        navigationController?.navigationBar.topItem?.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.add, target: self, action: #selector(addTaskButton))
        // MARK:
        retrieveData()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        NotificationCenter.default.addObserver(self, selector: #selector(retrieveData), name: NSNotification.Name("newData"), object: nil)
    }
    
    
    // MARK: Fetch data from Core Data
    @objc func retrieveData() {
        tasksArray.removeAll(keepingCapacity: false)
        idArray.removeAll(keepingCapacity: false)
        descriptionArray.removeAll()
        statusButtonArray.removeAll()
        dbArray.removeAll()
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "ToDoList")
        
        fetchRequest.sortDescriptors = [NSSortDescriptor.init(key: "listStatus", ascending: true)]
        fetchRequest.returnsObjectsAsFaults = false
        
        do {
            let results = try managedContext.fetch(fetchRequest)
            self.dbArray = results as! [NSManagedObject]
            for result in dbArray /*as! [NSManagedObject]*/ {
                if let title = result.value(forKey: "listTitle") as? String{
                    self.tasksArray.append(title)
                } else {
                    self.tasksArray.append("")
                }
                if let id = result.value(forKey: "id") as? UUID{
                    self.idArray.append(id)
                }  else {
                    self.idArray.append(UUID())
                }
                if let description = result.value(forKey: "listDescription") as? String {
                    self.descriptionArray.append(description)
                }  else {
                    self.descriptionArray.append("")
                }
                if let status = result.value(forKey: "listStatus") as? Bool {
                    self.statusButtonArray.append(status)
                }  else {
                    self.statusButtonArray.append(false)
                }
                
            }
            
            self.tableView.reloadData()
            
        } catch {
            print("error occured in view will appear fetch data")
        }
    }
    
    
    @objc func addTaskButton(_ sender: UIButton) {
        
        currentTaskTitle = ""
        currentDescription = ""
        performSegue(withIdentifier: "toInformationVC", sender: nil)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toInformationVC" {
            let destinationVC = segue.destination as! InformationVCViewController
            destinationVC.updateInformationVC.taskTitle = currentTaskTitle
            destinationVC.updateInformationVC.taskId = currentID
            destinationVC.updateInformationVC.taskDescription = currentDescription
            destinationVC.updateInformationVC.status = currentStatus
        }
    }
}


extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasksArray.count
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        currentTaskTitle = tasksArray[indexPath.row]
        currentID = idArray[indexPath.row]
        
        performSegue(withIdentifier: "toInformationVC", sender: nil)
    }
    
    // Add element in table view
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        cell.titleLabel?.text = tasksArray[indexPath.row]
        cell.statusButton.tag = indexPath.row
        
        if statusButtonArray[indexPath.row] == true {
            cell.statusButton.setTitle("Completed", for: UIControl.State.normal)
        } else {
            cell.statusButton.setTitle("Pending", for: .normal)
        }
        
        cell.statusButton.addTarget(self, action: #selector(statusButton(_:)), for: .touchUpInside)
        
        return cell
        
    }
    
    // Delete Data in table view
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            let appdelegate = UIApplication.shared.delegate as! AppDelegate
            let managedContext = appdelegate.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "ToDoList")
            
            let idString = idArray[indexPath.row].uuidString
            fetchRequest.predicate = NSPredicate(format: "id = %@", idString)
            
            do{
                let results = try managedContext.fetch(fetchRequest)
                if results.count > 0{
                    for result in results as! [NSManagedObject]{
                        if let id = result.value(forKey: "id") as? UUID{
                            if id == idArray[indexPath.row]{
                                
                                managedContext.delete(result)
                                
                                tasksArray.remove(at: indexPath.row)
                                idArray.remove(at: indexPath.row)
                                self.tableView.reloadData()
                                
                                do{
                                    try managedContext.save()
                                }catch{
                                    print("error")
                                }
                            }
                        }
                    }
                }
            }
            catch{
                print("error")
            }
        }
    }
    
    // MARK: Update Status button. Make it true if it is false and false if it is true.
    @objc func statusButton(_ sender: UIButton) {

            let index = IndexPath(row: sender.tag, section: 0)
            let newIndex = index.row

            if statusButtonArray[newIndex] == true {
                
            statusButtonArray[newIndex] = false
        } else {
            statusButtonArray[newIndex] = true
        }
        saveData(i: newIndex)
        self.tableView.reloadData()
        retrieveData()
    }
    
    // MARK: Save the new data of statusButtonArray at index i in core data and retrieve it to distinguish the completed and non completed tasks
    private func saveData(i: Int) {
        
        let object = self.dbArray[i]
        object.setValue(statusButtonArray[i], forKey: "listStatus")
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let managedContext = appDelegate?.persistentContainer.viewContext
        do{
            try managedContext?.save()
            self.retrieveData()
        }catch{
            print(error)
        }
    }
}
