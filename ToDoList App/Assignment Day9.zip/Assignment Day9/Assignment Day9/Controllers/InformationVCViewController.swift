//
//  InformationVCViewController.swift
//  Asignment Day 9
//
//  Created by amritansh kaushik on 07/02/23.
//

import UIKit
import CoreData


class InformationVCViewController: UIViewController, UITextFieldDelegate, UITextViewDelegate {
    
    
    @IBOutlet weak var titleTextField: UITextField!
    
    @IBOutlet weak var descriptionTextView: UITextView!
    
    @IBOutlet weak var saveTask: UIBarButtonItem!
    
    var updateInformationVC = UpdateInformationVC()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if updateInformationVC.taskTitle != "" || updateInformationVC.taskDescription != "" {
            let appdelegate = UIApplication.shared.delegate as! AppDelegate
            
            let managedContext = appdelegate.persistentContainer.viewContext
            
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "ToDoList")
            
            let idString = updateInformationVC.taskId?.uuidString
            fetchRequest.predicate = NSPredicate(format: "id = %@", idString!)
            
            do {
                let results = try managedContext.fetch(fetchRequest)
                if results.count > 0 {
                    
                    for result in results as! [NSManagedObject] {
                        if let title = result.value(forKey: "listTitle") as? String{
                            titleTextField.text = title
                        }
                        if let description = result.value(forKey: "listDescription") as? String {
                            descriptionTextView.text = description
                        }
                    }
                }
            } catch let error as NSError {
                print("The error is \(error)")
            }
        }
    }
    
    
    @IBAction func saveTaskButton(_ sender: Any) {
        
        if (titleTextField.text != updateInformationVC.taskTitle && updateInformationVC.taskTitle != "") || (descriptionTextView.text != updateInformationVC.taskDescription && updateInformationVC.taskDescription != "") {
            
            updateInformationVC.updateData(title: titleTextField.text!, description: descriptionTextView.text)
            
        } else {
            
            updateInformationVC.createData(title: titleTextField.text!, description: descriptionTextView.text)
        }
        NotificationCenter.default.post(name: NSNotification.Name("newData"), object: nil)
        self.navigationController?.popViewController(animated: true)
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
